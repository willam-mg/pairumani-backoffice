<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Admin\RolController;
use App\Http\Controllers\Admin\EventoController;
use App\Http\Controllers\Admin\ClienteController;
use App\Http\Controllers\Admin\UsuarioController;
use App\Http\Controllers\Admin\AcompananteController;
use App\Http\Controllers\admin\HabitacionCategoriaController;
use App\Http\Controllers\Admin\HabitacionController;
use App\Http\Controllers\Admin\PromocionController;

// Route::group(['middleware' => ['auth','permisos']], function () {
Route::group(['middleware' => ['auth']], function () {

    //RUTAS ACOMPAÑANTES
    Route::get('acompañantes',[AcompananteController::class,'index'])->name('acompanantes_index');
    Route::get('acompañantes/create', [AcompananteController::class, 'create'])->name('acompanantes_create');
    Route::post('acompañantes/create', [AcompananteController::class, 'store'])->name('acompanantes_create');
    Route::get('acompañantes/{acompanante}', [AcompananteController::class, 'show'])->name('acompanantes_show');
    Route::get('acompañantes/{acompanante}/edit', [AcompananteController::class, 'edit'])->name('acompanantes_edit');
    Route::post('acompañantes/{acompanante}/edit', [AcompananteController::class, 'update'])->name('acompanantes_edit');
    Route::delete('acompañantes/{acompanante}', [AcompananteController::class, 'destroy'])->name('acompanantes_destroy');

    //RUTAS CLIENTES
    Route::get('clientes', [ClienteController::class, 'index'])->name('clientes_index');
    Route::get('clientes/create', [ClienteController::class, 'create'])->name('clientes_create');
    Route::post('clientes/create', [ClienteController::class, 'store'])->name('clientes_create');
    Route::get('clientes/{cliente}', [ClienteController::class, 'show'])->name('clientes_show');
    Route::get('clientes/{cliente}/edit', [ClienteController::class, 'edit'])->name('clientes_edit');
    Route::post('clientes/{cliente}/edit', [ClienteController::class, 'update'])->name('clientes_edit');
    Route::delete('clientes/{cliente}', [ClienteController::class, 'destroy'])->name('clientes_destroy');

    //RUTAS EVENTOS
    Route::get('eventos', [EventoController::class, 'index'])->name('eventos_index');
    Route::get('eventos/create', [EventoController::class, 'create'])->name('eventos_create');
    Route::post('eventos/create', [EventoController::class, 'store'])->name('eventos_create');
    Route::get('eventos/{evento}', [EventoController::class, 'show'])->name('eventos_show');
    Route::get('eventos/{evento}/edit', [EventoController::class, 'edit'])->name('eventos_edit');
    Route::post('eventos/{evento}/edit', [EventoController::class, 'update'])->name('eventos_edit');
    Route::get('eventos/{evento}/fotos', [EventoController::class, 'fotos'])->name('eventos_galeria');
    Route::post('eventos/{evento}/fotos', [EventoController::class, 'fotosstore'])->name('eventos_galeria');
    Route::delete('eventos/{evento}/fotos/{galeria}', [EventoController::class, 'fotosdelete'])->name('eventos_galeria_destroy');
    Route::delete('eventos/{evento}', [EventoController::class, 'destroy'])->name('eventos_destroy');

    //RUTAS CATEGORIAS HABITACIONES
    Route::get('habitacioncategorias', [HabitacionCategoriaController::class, 'index'])->name('habitacioncategorias_index');
    Route::get('habitacioncategorias/create', [HabitacionCategoriaController::class, 'create'])->name('habitacioncategorias_create');
    Route::post('habitacioncategorias/create', [HabitacionCategoriaController::class, 'store'])->name('habitacioncategorias_create');
    Route::get('habitacioncategorias/{categoria}', [HabitacionCategoriaController::class, 'show'])->name('habitacioncategorias_show');
    Route::get('habitacioncategorias/{categoria}/edit', [HabitacionCategoriaController::class, 'edit'])->name('habitacioncategorias_edit');
    Route::post('habitacioncategorias/{categoria}/edit', [HabitacionCategoriaController::class, 'update'])->name('habitacioncategorias_edit');
    Route::delete('habitacioncategorias/{categoria}', [HabitacionCategoriaController::class, 'destroy'])->name('habitacioncategorias_destroy');

    //RUTAS HABITACIONES
    Route::get('habitaciones', [HabitacionController::class, 'index'])->name('habitaciones_index');
    Route::get('habitaciones/create', [HabitacionController::class, 'create'])->name('habitaciones_create');
    Route::post('habitaciones/create', [HabitacionController::class, 'store'])->name('habitaciones_create');
    Route::get('habitaciones/{habitacion}', [HabitacionController::class, 'show'])->name('habitaciones_show');
    Route::get('habitaciones/{habitacion}/edit', [HabitacionController::class, 'edit'])->name('habitaciones_edit');
    Route::post('habitaciones/{habitacion}/edit', [HabitacionController::class, 'update'])->name('habitaciones_edit');
    Route::get('habitaciones/{habitacion}/fotos', [HabitacionController::class, 'fotos'])->name('habitaciones_galeria');
    Route::post('habitaciones/{habitacion}/fotos', [HabitacionController::class, 'fotosstore'])->name('habitaciones_galeria');
    Route::delete('habitaciones/{habitacion}/fotos/{galeria}', [HabitacionController::class, 'fotosdelete'])->name('habitaciones_galeria_destroy');
    Route::delete('habitaciones/{habitacion}', [HabitacionController::class, 'destroy'])->name('habitaciones_destroy');

    //RUTAS PROMOCIONES
    Route::get('promociones', [PromocionController::class, 'index'])->name('promociones_index');
    Route::get('promociones/create', [PromocionController::class, 'create'])->name('promociones_create');
    Route::post('promociones/create', [PromocionController::class, 'store'])->name('promociones_create');
    Route::get('promociones/{promocion}', [PromocionController::class, 'show'])->name('promociones_show');
    Route::get('promociones/{promocion}/edit', [PromocionController::class, 'edit'])->name('promociones_edit');
    Route::post('promociones/{promocion}/edit', [PromocionController::class, 'update'])->name('promociones_edit');
    Route::delete('promociones/{promocion}', [PromocionController::class, 'destroy'])->name('promociones_destroy');

    //RUTAS ROLES
    Route::get('roles', [RolController::class, 'index'])->name('roles_index');
    Route::get('roles/reporte', [RolController::class, 'pdf'])->name('roles_reporte');
    Route::get('roles/create', [RolController::class, 'create'])->name('roles_create');
    Route::post('roles/create', [RolController::class, 'store'])->name('roles_create');
    Route::get('roles/{rol}', [RolController::class, 'show'])->name('roles_show');
    Route::get('roles/{rol}/edit', [RolController::class, 'edit'])->name('roles_edit');
    Route::post('roles/{rol}/edit', [RolController::class, 'update'])->name('roles_edit');
    Route::delete('roles/{rol}', [RolController::class, 'destroy'])->name('roles_destroy');
    Route::get('roles/{rol}/permisos', [RolController::class, 'getrolpermisos'])->name('roles_permisos');
    Route::post('roles/{rol}/permisos', [RolController::class, 'postrolpermisos'])->name('roles_permisos');

    //RUTAS USUARIOS
    Route::get('usuarios', [UsuarioController::class, 'index'])->name('usuarios_index');
    Route::get('usuarios/pdf', [UsuarioController::class, 'pdf'])->name('usuarios_reporte');
    Route::get('usuarios/create', [UsuarioController::class, 'create'])->name('usuarios_create');
    Route::post('usuarios/create', [UsuarioController::class, 'store'])->name('usuarios_create');
    Route::get('usuarios/{usuario}/edit', [UsuarioController::class, 'edit'])->name('usuarios_edit');
    Route::post('usuarios/{usuario}/edit', [UsuarioController::class, 'update'])->name('usuarios_edit');
    Route::delete('usuarios/{usuario}', [UsuarioController::class, 'destroy'])->name('usuarios_destroy');
});

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();
Route::get('/{slug?}', [HomeController::class,'index']);
Route::get('/home', [HomeController::class, 'index'])->name('home');
