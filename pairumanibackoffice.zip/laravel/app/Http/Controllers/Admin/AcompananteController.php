<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AcompananteFormRequest;
use App\Models\Acompanante;
use App\Models\HospedajeDetalle;
use Illuminate\Http\Request;

class AcompananteController extends Controller
{
    public function index(Request $request)
    {
        if ($request) {
            $query = trim($request->get('searchText'));
            $acompañantes = Acompanante::where('nombre', 'LIKE', '%' . $query . '%')
                ->orwhere('tipo_documento','LIKE','%'. $query .'%')
                ->orderBy('id', 'desc')
                ->paginate(7);
            return view('acompanantes.index', ["acompañantes" => $acompañantes, "searchText" => $query]);
        }
    }
    public function show(Acompanante $acompanante)
    {
        return view('acompanantes.show',compact('acompanante'));
    }
    public function create()
    {
        return view('acompanantes.create',[
            'acompanante' => new Acompanante()
        ]);
    }
    public function store(AcompananteFormRequest $request)
    {
        $acompanante = (new Acompanante())->fill($request->all());
        $acompanante->save();
        return redirect()->route('acompanantes_index')->with('message', 'Guardado con éxito')->with('typealert', 'success');
    }
    public function edit(Acompanante $acompanante)
    {
        return view('acompanantes.edit',compact('acompanante'));
    }
    public function update(AcompananteFormRequest $request, Acompanante $acompanante)
    {
        $acompanante->update($request->all());
        return redirect()->route('acompanantes_index')->with('message', 'Modificado con éxito')->with('typealert', 'success');
    }
    public function destroy(Acompanante $acompanante)
    {
        $existe = HospedajeDetalle::where('acompanante_id',$acompanante->id)->exists();
        if($existe){
            return back()->with('message', 'No se puede eliminar el acompanante')->with('typealert', 'danger');
        }
        $acompanante->delete();
        return redirect()->route('acompanantes_index')->with('message', 'Eliminado con éxito')->with('typealert', 'success');
    }
}