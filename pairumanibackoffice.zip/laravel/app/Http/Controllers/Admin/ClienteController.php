<?php

namespace App\Http\Controllers\Admin;

use App\Models\Cliente;
use App\Models\Reserva;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\ClienteFormRequest;

class ClienteController extends Controller
{
    public function index(Request $request)
    {
        if ($request) {
            $query = trim($request->get('searchText'));
            $clientes = Cliente::where('nombres', 'LIKE', '%' . $query . '%')
                ->orwhere('apellidos','LIKE','%'.$query.'%')
                ->orwhere('tipo_documento', 'LIKE', '%' . $query . '%')
                ->orwhere('num_documento', 'LIKE', '%' . $query . '%')
                ->orwhere('celular', 'LIKE', '%' . $query . '%')
                ->orderBy('id', 'desc')
                ->paginate(7);
            return view('clientes.index', ["clientes" => $clientes, "searchText" => $query]);
        }
    }
    public function show(Cliente $cliente)
    {
        return view('clientes.show',compact('cliente'));
    }
    public function create()
    {
        return view('clientes.create', [
            'cliente' => new Cliente()
        ]);
    }
    public function store(ClienteFormRequest $request)
    {
        $cliente = (new Cliente())->fill($request->all());
        $cliente->api_token = str::random('60');
        $cliente->password = Hash::make($request->get('email'));
        $cliente->save();
        return redirect()->route('clientes_index')->with('message', 'Guardado con éxito')->with('typealert', 'success');
    }
    public function edit(Cliente $cliente)
    {
        return view('clientes.edit', compact('cliente'));
    }
    public function update(ClienteFormRequest $request, Cliente $cliente)
    {
        $cliente->update($request->all());
        return redirect()->route('clientes_index')->with('message', 'Modificado con éxito')->with('typealert', 'success');
    }
    public function destroy(Cliente $cliente)
    {
        $existe = Reserva::where('cliente_id', $cliente->id)->exists();
        if ($existe) {
            return back()->with('message', 'No se puede eliminar el cliente')->with('typealert', 'danger');
        }
        $cliente->delete();
        return redirect()->route('clientes_index')->with('message', 'Eliminado con éxito')->with('typealert', 'success');
    }
}
