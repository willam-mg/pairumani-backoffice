<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ClienteFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'tipo_documento' => 'required|in:Ci,Dni,Pasaporte',
            'direccion' => 'required|max:50',
            'ciudad' => 'required|max:50',
            'pais' => 'required|max:50',
            'oficio' => 'required|max:50',
            'empresa' => 'required|max:50',
            'fecha_nacimiento' => 'required|date_format:Y-m-d',
            'motivo_viaje' => 'required|in:Recreacion,Negocios,Salud,Otro',
            'password' => 'max:50|unique:clientes',
        ];

        if (routerequest('clientes_create')) {
            $rules['nombres'] = ['required', 'max:50', 'unique:clientes'];
            $rules['apellidos'] = ['required', 'max:50', 'unique:clientes'];
            $rules['num_documento'] = ['required', 'max:50', 'unique:clientes'];
            $rules['celular'] = ['required', 'max:50', 'unique:clientes'];
            $rules['telefono'] = ['required', 'max:50', 'unique:clientes'];
            $rules['email'] = ['required', 'max:50', 'unique:clientes'];
            // $rules['password'] = ['required', 'max:50', 'unique:clientes'];
        }

        if (routerequest('clientes_edit')) {
            $rules['nombres'] = ['required', 'max:50'];
            $rules['apellidos'] = ['required', 'max:50'];
            $rules['num_documento'] = ['required', 'max:50'];
            $rules['celular'] = ['required', 'max:50'];
            $rules['telefono'] = ['required', 'max:50'];
            $rules['email'] = ['required', 'max:50'];
            // $rules['password'] = ['required', 'max:50'];
        }

        return $rules;
    }
}
