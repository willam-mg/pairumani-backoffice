<ul class="nav">
    {{-- @if(Auth::user()->rol_id == null)
        
    @else  --}}
        {{-- @if(kvfj(Auth::user()->rol->permisos,'usuarios_index')) --}}
            <!-- SECCION USUARIOS -->
            <li class="nav-item {{ setActiveRoute(['usuarios_index','usuarios_create','usuarios_edit']) }}">
                <a href="{{ route('usuarios_index') }}" class="nav-link">
                    <i class="material-icons">people_alt</i>
                    <p>
                        Usuarios
                    </p>
                </a>
            </li>
        {{-- @endif
        {{-- @if(kvfj(Auth::user()->rol->permisos,'roles_index')) --}}
            <!-- SECCION ROLES -->
            <li class="nav-item {{ setActiveRoute(['roles_index','roles_create','roles_edit','roles_permisos']) }}">
                <a href="{{ route('roles_index') }}" class="nav-link">
                    <i class="material-icons">privacy_tip</i>
                    <p>
                        Roles
                    </p>
                </a>
            </li>
        {{-- @endif        
        {{-- @if(kvfj(Auth::user()->rol->permisos,'acompanantes_index')) --}}
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item {{ setActiveRoute(['acompanantes_index','acompanantes_create','acompanantes_edit','acompanantes_show']) }}">
                <a href="{{ route('acompanantes_index') }}" class="nav-link">
                    <i class="material-icons">people_alt</i>
                    <p>
                        Acompañantes
                    </p>
                </a>
            </li>
        {{-- @endif --}}
        {{-- @if(kvfj(Auth::user()->rol->permisos,'clientes_index')) --}}
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item {{ setActiveRoute(['clientes_index','clientes_create','clientes_edit','clientes_show']) }}">
                <a href="{{ route('clientes_index') }}" class="nav-link">
                    <i class="material-icons">people_alt</i>
                    <p>
                        Clientes
                    </p>
                </a>
            </li>
        {{-- @endif --}}        
        {{-- @if(kvfj(Auth::user()->rol->permisos,'eventos_index')) --}}
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item {{ setActiveRoute(['eventos_index','eventos_create','eventos_edit','eventos_show','eventos_galeria']) }}">
                <a href="{{ route('eventos_index') }}" class="nav-link">
                    <i class="material-icons">event</i>
                    <p>
                        Eventos
                    </p>
                </a>
            </li>
        {{-- @endif --}}        
        {{-- @if(kvfj(Auth::user()->rol->permisos,'habitacioncategorias_index')) --}}
            <!-- SECCION HABITACION CATEGORIAS -->
            <li class="nav-item {{ setActiveRoute(['habitacioncategorias_index','habitacioncategorias_create','habitacioncategorias_edit','habitacioncategorias_show']) }}">
                <a href="{{ route('habitacioncategorias_index') }}" class="nav-link">
                    <i class="material-icons">assignment</i>
                    <p>
                        Habitacion Categorias
                    </p>
                </a>
            </li>
        {{-- @endif --}}        
        {{-- @if(kvfj(Auth::user()->rol->permisos,'habitaciones_index')) --}}
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item {{ setActiveRoute(['habitaciones_index','habitaciones_create','habitaciones_edit','habitaciones_show','habitaciones_galeria']) }}">
                <a href="{{ route('habitaciones_index') }}" class="nav-link">
                    <i class="material-icons">meeting_room</i>
                    <p>
                        Habitaciones
                    </p>
                </a>
            </li>
        {{-- @endif --}}        
        {{-- @if(kvfj(Auth::user()->rol->permisos,'promociones_index')) --}}
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item {{ setActiveRoute(['promociones_index','promociones_create','promociones_edit','promociones_show']) }}">
                <a href="{{ route('promociones_index') }}" class="nav-link">
                    <i class="material-icons">campaign</i>
                    <p>
                        Promociones
                    </p>
                </a>
            </li>
        {{-- @endif --}}        
    {{-- @endif --}}
</ul>