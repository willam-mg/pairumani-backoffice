
<?php $__env->startSection('header'); ?>
    <!-- Content Header (Page header) -->
    <div class="card">
        <div class="card-body py-3 justify-content-between align-items-center">
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Listado de Habitaciones</h3>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right" style="background-color: inherit">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                        <li class="breadcrumb-item active">Habitaciones</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div>
    </div>
    <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
	<div class="content">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                    <div class="card-header card-header-icon card-header-rose">
                        <div class="card-icon">
                            <i class="material-icons">date_range</i>
                        </div>
                        <div style="text-align: right;padding-top: 15px;">
                            
                                <a class="btn btn-success" href="<?php echo e(route('habitaciones_create')); ?>" title="Nuevo habitacion">
                                    <i class="material-icons">add</i> Nuevo
                                </a>
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <div class="col-7">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <?php echo $__env->make('habitaciones.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <table class="table table-striped table-bordered table-condensed">
                                <thead class="text-primary">
                                    <th>Id</th>
                                    <th>Foto</th>
									<th>Nombre</th>
									<th>Num Habitacion</th>
                                    <th>Precio</th>
                                    <th>Capacidad Minima</th>
                                    <th>Estado</th>
									<th>Categoria</th>
									<th>Opciones</th>
                                </thead>
                               <tbody>
									<?php if(count($habitaciones)): ?>
										<?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($habitacion->id); ?></td>
												<td>
                                                    <img src="<?php echo e($habitacion->fotourl); ?>" alt="<?php echo e($habitacion->nombre); ?>" height="120px" width="120px" class="img-">
                                                </td>
												<td><?php echo e($habitacion->nombre); ?></td>
												<td><?php echo e($habitacion->num_habitacion); ?></td>
												<td><?php echo e($habitacion->precio); ?></td>
												<td><?php echo e($habitacion->capacidad_minima); ?></td>
												<td><?php echo e($habitacion->estado); ?></td>
												<td><?php echo e($habitacion->categoria->nombre); ?></td>
												<td style="width: 250px; text-align: center;">
                                                    
                                                        <a href="<?php echo e(route('habitaciones_galeria',$habitacion->id)); ?>" class="btn btn-success btn-round btn-just-icon" title="Galeria habitacion">
                                                            <i class="material-icons">photo_size_select_actual</i>
                                                        </a>
                                                    
                                                    
                                                        <a href="<?php echo e(route('habitaciones_show',$habitacion->id)); ?>" class="btn btn-info btn-round btn-just-icon" title="Detalle habitacion">
                                                            <i class="material-icons">visibility</i>
                                                        </a>
                                                    
													
														<a href="<?php echo e(route('habitaciones_edit',$habitacion->id)); ?>" class="btn btn-warning btn-round btn-just-icon" title="Editar habitacion">
															<i class="material-icons">mode_edit</i>
														</a>
													
													
                                                        <a href="" data-target="#modal-delete-<?php echo e($habitacion->id); ?>" data-toggle="modal"  class="btn btn-danger btn-round btn-just-icon" title="Eliminar habitacion">
                                                            <i class="material-icons">delete</i>
                                                        </a>
													
												</td>
											</tr>
											<?php echo $__env->make('habitaciones.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<tr>
											<td colspan="9" style="text-align: center;">
												<h2><span class="badge badge-danger" style="font-size: 20px">No Existen habitaciones</span></h2>
											</td>
										</tr>
									<?php endif; ?>
								</tbody>
                            </table>
                            <?php echo e($habitaciones->appends(request()->all())->render()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/habitaciones/index.blade.php ENDPATH**/ ?>