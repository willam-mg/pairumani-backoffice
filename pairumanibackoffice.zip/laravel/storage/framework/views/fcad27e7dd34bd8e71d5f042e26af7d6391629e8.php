<?php echo csrf_field(); ?>
<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">assignment</i>
        </div>
    </div>
    <div class="card-body ">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('nombre') ? 'has-danger' : ''); ?>">
                <label for="nombre" class="bmd-label-floating">Nombre</label>
                <input type="text" name="nombre" value="<?php echo e(old('nombre', $usuario->nombre)); ?>" class="form-control">
                <?php if($errors->has('nombre')): ?>
                    <span id="nombre-error" for="nombre" class="error"><?php echo e($errors->first('nombre')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('apellido') ? 'has-danger' : ''); ?>">
                <label for="apellido" class="bmd-label-floating">Apellido</label>
                <input type="text" name="apellido" value="<?php echo e(old('apellido', $usuario->apellido)); ?>" class="form-control">
                <?php if($errors->has('apellido')): ?>
                    <span id="apellido-error" for="apellido" class="error"><?php echo e($errors->first('apellido')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('email') ? 'has-danger' : ''); ?>">
                <label for="email" class="bmd-label-floating">Email</label>
                <input type="email" name="email" value="<?php echo e(old('email', $usuario->email)); ?>" class="form-control">
                <?php if($errors->has('email')): ?>
                    <span id="email-error" for="email" class="error"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('telefono') ? 'has-danger' : ''); ?>">
                <label for="telefono" class="bmd-label-floating">Telefono</label>
                <input type="number" min="0" name="telefono" value="<?php echo e(old('telefono', $usuario->telefono)); ?>" class="form-control">
                <?php if($errors->has('telefono')): ?>
                    <span id="telefono-error" for="telefono" class="error"><?php echo e($errors->first('telefono')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('direccion') ? 'has-danger' : ''); ?>">
                <label for="direccion" class="bmd-label-floating">Direccion</label>
                <input type="text" name="direccion" value="<?php echo e(old('direccion', $usuario->direccion)); ?>" class="form-control">
                <?php if($errors->has('direccion')): ?>
                    <span id="direccion-error" for="direccion" class="error"><?php echo e($errors->first('direccion')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('password') ? 'has-danger' : ''); ?>">
                <label for="password" class="bmd-label-floating">Password</label>
                <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control">
                <?php if($errors->has('password')): ?>
                    <span id="password-error" for="password" class="error"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>
        </div>    
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('rol_id') ? 'has-danger' : ''); ?>">
                <label for="rol_id">Roles</label>
                <select name="rol_id" class="form-control select2bs4">
                    <option>Seleccione un rol</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('rol_id', $usuario->rol_id) == $key ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('rol_id')): ?>
                    <span id="rol_id-error" for="rol_id" class="error"><?php echo e($errors->first('rol_id')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="card-footer text-right">
        <div class="form-group">
            <button class="btn btn-primary" type="submit">
                <i class="material-icons">save</i> Guardar
            </button>
            <a href="<?php echo e(route('usuarios_index')); ?>" class="btn btn-danger">
                <i class="material-icons">clear</i> Cancelar
            </a>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/usuarios/form.blade.php ENDPATH**/ ?>