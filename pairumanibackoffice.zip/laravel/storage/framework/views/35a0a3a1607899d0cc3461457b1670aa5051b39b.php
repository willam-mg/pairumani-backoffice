<?php echo csrf_field(); ?>
<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">assignment</i>
        </div>
    </div>
    <div class="card-body ">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('nombre') ? 'has-danger' : ''); ?>">
                <label for="nombre" class="bmd-label-floating">Nombre</label>
                <input type="text" name="nombre" value="<?php echo e(old('nombre', $promocion->nombre)); ?>" class="form-control" autofocus>
                <?php if($errors->has('nombre')): ?>
                    <span id="nombre-error" for="nombre" class="error"><?php echo e($errors->first('nombre')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <label for="descripcion"><strong>Descripcion</strong></label>
            <div class="form-group bmd-form-group <?php echo e($errors->has('descripcion') ? 'has-danger' : ''); ?>">
                <textarea name="descripcion" id="editor" class="form-control" cols="30" rows="10"><?php echo e(old('descripcion', $promocion->descripcion)); ?></textarea>
                <?php if($errors->has('descripcion')): ?>
                    <span id="descripcion-error" for="descripcion" class="error"><?php echo e($errors->first('descripcion')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <h4 for="foto">Foto</h4>
            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                <div class="fileinput-new thumbnail">
                    <?php if(($promocion->foto)!=""): ?>
                        <img src="<?php echo e($promocion->fotourl); ?>" height="300px" width="300px">
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="...">
                    <?php endif; ?>
                </div>
                <div class="fileinput-preview fileinput-exists thumbnail"></div>
                <div>
                    <span class="btn btn-rose btn-round btn-file">
                        <span class="fileinput-new">Seleccione una imagen</span>
                        <span class="fileinput-exists">Change</span>
                        <input type="file" name="foto" value="<?php echo e(old('foto',$promocion->foto)); ?>">
                    </span>
                    <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                </div>
                <div class="form-group <?php echo e($errors->has('foto') ? 'has-danger' : ''); ?>">
                    <?php if($errors->has('foto')): ?>
                        <span id="foto-error" for="foto" class="error"><?php echo e($errors->first('foto')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('precio') ? 'has-danger' : ''); ?>">
                <label for="precio" class="bmd-label-floating">precio</label>
                <input type="text" name="precio" value="<?php echo e(old('precio', $promocion->precio)); ?>" class="form-control" autofocus>
                <?php if($errors->has('precio')): ?>
                    <span id="precio-error" for="precio" class="error"><?php echo e($errors->first('precio')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('estado') ? 'has-danger' : ''); ?>">
                <label for="estado">Estado</label>
                <select name="estado" class="form-control select2bs4">
                    <option>Seleccione un estado</option>
                    <option value="Activo" <?php echo e(old('estado', $promocion->estado) == 'Activo' ? 'selected' : ''); ?>>Activo</option>
                    <option value="Inactivo" <?php echo e(old('estado', $promocion->estado) == 'Inactivo' ? 'selected' : ''); ?>>Inactivo</option>
                </select>
                <?php if($errors->has('estado')): ?>
                    <span id="estado-error" for="estado" class="error"><?php echo e($errors->first('estado')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="card-footer text-right">
        <div class="form-group">
            <button class="btn btn-primary" type="submit">
                <i class="material-icons">save</i> Guardar
            </button>
            <a href="<?php echo e(route('promociones_index')); ?>" class="btn btn-danger">
                <i class="material-icons">clear</i> Cancelar
            </a>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        $(function(){
            CKEDITOR.replace('editor');
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/promociones/form.blade.php ENDPATH**/ ?>