<?php $__env->startSection('titulo','Inicio'); ?>
<?php $__env->startSection('contenido'); ?>
	<div class="section">
		<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
			<section class="content">
				<div class="row">
					<?php if(Auth::user()->rol_id == null): ?>
						<div class="alert alert-dismissable alert-danger">
							<button type="button" class="close" data-dismiss="alert"></button>
							<h4>Mensaje del sistema!</h4><br>
							<h2>Usted no cuenta con ningun rol asigando, comuniquese con el administrador del sistema porfavor</h2>							
						</div>
					<?php else: ?>						
						<?php if(kvfj(Auth::user()->rol->permisos,'usuarios_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-warning card-header-icon">
										<div class="card-icon">
											<i class="material-icons">people_alt</i>
										</div>
										<p class="card-category">Usuarios</p>
										<h3 class="card-title"><?php echo e($usuarios); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('usuarios_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php if(kvfj(Auth::user()->rol->permisos,'usuariosapp_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-info card-header-icon">
										<div class="card-icon">
											<i class="material-icons">people_alt</i>
										</div>
										<p class="card-category">Usuariosapp</p>
										<h3 class="card-title"><?php echo e($usuariosapp); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('usuariosapp_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php if(kvfj(Auth::user()->rol->permisos,'categorias_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-success card-header-icon">
										<div class="card-icon">
											<i class="material-icons">assignment</i>
										</div>
										<p class="card-category">Categorias</p>
										<h3 class="card-title"><?php echo e($categorias); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('categorias_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php if(kvfj(Auth::user()->rol->permisos,'roles_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-warning card-header-icon">
										<div class="card-icon">
											<i class="material-icons">privacy_tip</i>
										</div>
										<p class="card-category">Roles</p>
										<h3 class="card-title"><?php echo e($roles); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('roles_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php if(kvfj(Auth::user()->rol->permisos,'comercios_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-danger card-header-icon">
										<div class="card-icon">
											<i class="material-icons">dining</i>
										</div>
										<p class="card-category">Comercios</p>
										<h3 class="card-title"><?php echo e($comercios); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('comercios_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php if(kvfj(Auth::user()->rol->permisos,'departamentos_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-primary card-header-icon">
										<div class="card-icon">
											<i class="material-icons">location_city</i>
										</div>
										<p class="card-category">Departamentos</p>
										<h3 class="card-title"><?php echo e($departamentos); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('departamentos_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php if(kvfj(Auth::user()->rol->permisos,'pagos_index')): ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header card-header-danger card-header-icon">
										<div class="card-icon">
											<i class="material-icons">attach_money</i>
										</div>
										<p class="card-category">Pagos</p>
										<h3 class="card-title"><?php echo e($pagos); ?></h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<a href="<?php echo e(route('pagos_index')); ?>">Más información</a>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			</section>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hotel\laravel\resources\views/home.blade.php ENDPATH**/ ?>