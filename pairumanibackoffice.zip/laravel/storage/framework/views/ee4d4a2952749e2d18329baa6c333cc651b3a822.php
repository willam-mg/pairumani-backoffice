<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-delete-<?php echo e($categoria->id); ?>">
	<form method="POST" action="<?php echo e(route('habitacioncategorias_destroy',$categoria->id)); ?>">
		<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Eliminar Habitación Categoria</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">x</span>					
					</button>
				</div>
				<div class="modal-body">
					<p>Confirme si desea Elimnar el Habitación Categoria</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
					<button name="confirmar" type="submit" class="btn btn-primary">Confirmar</button>
				</div>
			</div>
		</div>
	</form>
</div><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/habitacioncategorias/modal.blade.php ENDPATH**/ ?>