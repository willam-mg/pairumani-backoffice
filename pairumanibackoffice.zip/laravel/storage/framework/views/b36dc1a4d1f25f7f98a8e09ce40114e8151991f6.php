<?php echo csrf_field(); ?>
<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">assignment</i>
        </div>
    </div>
    <div class="card-body ">
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('nombre') ? 'has-danger' : ''); ?>">
                <label for="nombre" class="bmd-label-floating">Nombre</label>
                <input type="text" name="nombre" value="<?php echo e(old('nombre', $evento->nombre)); ?>" class="form-control" autofocus>
                <?php if($errors->has('nombre')): ?>
                    <span id="nombre-error" for="nombre" class="error"><?php echo e($errors->first('nombre')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <label for="descripcion"><strong>Descripcion</strong></label>
            <div class="form-group bmd-form-group <?php echo e($errors->has('descripcion') ? 'has-danger' : ''); ?>">
                <textarea name="descripcion" id="editor" class="form-control" cols="30" rows="10"><?php echo e(old('descripcion', $evento->descripcion)); ?></textarea>
                <?php if($errors->has('descripcion')): ?>
                    <span id="descripcion-error" for="descripcion" class="error"><?php echo e($errors->first('descripcion')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <h4 for="foto">Foto</h4>
            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                <div class="fileinput-new thumbnail">
                    <?php if(($evento->foto)!=""): ?>
                        <img src="<?php echo e($evento->fotourl); ?>" height="300px" width="300px">
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="...">
                    <?php endif; ?>
                </div>
                <div class="fileinput-preview fileinput-exists thumbnail"></div>
                <div>
                    <span class="btn btn-rose btn-round btn-file">
                        <span class="fileinput-new">Seleccione una imagen</span>
                        <span class="fileinput-exists">Change</span>
                        <input type="file" name="foto" value="<?php echo e(old('foto',$evento->foto)); ?>">
                    </span>
                    <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                </div>
                <div class="form-group <?php echo e($errors->has('foto') ? 'has-danger' : ''); ?>">
                    <?php if($errors->has('foto')): ?>
                        <span id="foto-error" for="foto" class="error"><?php echo e($errors->first('foto')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
            <div class="form-group bmd-form-group <?php echo e($errors->has('fecha') ? 'has-danger' : ''); ?>">
                <label for="fecha" class="bmd-label-floating">Fecha</label>
                <input type="date" name="fecha" value="<?php echo e(old('fecha',$evento->fecha)); ?>" class="form-control">
                <?php if($errors->has('fecha')): ?>
                    <span id="fecha-error" for="fecha" class="error"><?php echo e($errors->first('fecha')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="card-footer text-right">
        <div class="form-group">
            <button class="btn btn-primary" type="submit">
                <i class="material-icons">save</i> Guardar
            </button>
            <a href="<?php echo e(route('eventos_index')); ?>" class="btn btn-danger">
                <i class="material-icons">clear</i> Cancelar
            </a>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        $(function(){
            CKEDITOR.replace('editor');
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/eventos/form.blade.php ENDPATH**/ ?>