
<?php $__env->startSection('header'); ?>
    <!-- Content Header (Page header) -->
    <div class="card">
        <div class="card-body py-3 justify-content-between align-items-center">
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Galeria evento: <?php echo e($evento->nombre); ?></h3>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right" style="background-color: inherit">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
						<li class="breadcrumb-item"><a href="<?php echo e(route('eventos_index')); ?>">Eventos</a></li>
						<li class="breadcrumb-item"><a href="<?php echo e(route('eventos_index')); ?>">Evento <?php echo e($evento->nombre); ?></a></li>
                        <li class="breadcrumb-item active">Galeria Evento</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div>
    </div>
    <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="row">
                <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('eventos_galeria',$evento->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                                        <h4 for="foto">foto</h4>
                                        <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail">
                                                <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="...">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                            <div>
                                                <span class="btn btn-rose btn-round btn-file">
                                                    <span class="fileinput-new">Seleccione una imagen</span>
                                                    <span class="fileinput-exists">Change</span>
                                                    <input type="file" name="foto" value="<?php echo e(old('foto')); ?>">
                                                </span>
                                                <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                            <div class="form-group <?php echo e($errors->has('foto') ? 'has-danger' : ''); ?>">
                                                <?php if($errors->has('foto')): ?>
                                                    <span id="foto-error" for="foto" class="error"><?php echo e($errors->first('foto')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group d-flex">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="material-icons">save</i> Guardar
                                    </button>
                                    <a href="<?php echo e(route('eventos_index')); ?>" class="btn btn-danger">
                                        <i class="material-icons">clear</i> Cancelar
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-sm-9 col-md-9 col-xs-12">
                    <div class="row">
                        <?php $__currentLoopData = $evento->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form method="POST" action="<?php echo e(route('eventos_galeria_destroy',[$evento->id,$foto->id])); ?>">
                                <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
                                <div class="col-md-3">
                                    
                                        <button class="btn btn-danger btn-xs" style="position: absolute" type="submit" title="Eliminar foto">
                                            <i class="material-icons">clear</i>
                                        </button>
                                    
                                    <img src="<?php echo e($foto->fotourl); ?>" alt="<?php echo e($evento->nombre); ?>" width="150px" height="150px">
                                </div>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
			</div>
    	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/eventos/fotos.blade.php ENDPATH**/ ?>