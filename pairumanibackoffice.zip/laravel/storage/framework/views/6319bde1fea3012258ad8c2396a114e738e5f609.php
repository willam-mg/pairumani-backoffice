
<?php $__env->startSection('header'); ?>
    <!-- Content Header (Page header) -->
    <div class="card">
        <div class="card-body py-3 justify-content-between align-items-center">
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Nueva Promocion</h3>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right" style="background-color: inherit">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
						<li class="breadcrumb-item"><a href="<?php echo e(route('promociones_index')); ?>">Promociones</a></li>
                        <li class="breadcrumb-item active">Nueva Promocion</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div>
    </div>
    <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-8 ml-auto mr-auto">
					<form method="POST" action="<?php echo e(route('promociones_create')); ?>" enctype="multipart/form-data">
						<?php echo $__env->make('promociones.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</form>
				</div>
			</div>
    	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/promociones/create.blade.php ENDPATH**/ ?>