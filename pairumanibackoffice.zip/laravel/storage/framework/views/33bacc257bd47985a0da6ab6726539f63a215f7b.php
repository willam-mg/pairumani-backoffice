
<?php $__env->startSection('header'); ?>
    <!-- Content Header (Page header) -->
    <div class="card">
        <div class="card-body py-3 justify-content-between align-items-center">
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Permisos de Rol: <?php echo e($rol->nombre); ?> (ID: <?php echo e($rol->id); ?>)</h3>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right" style="background-color: inherit">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('roles_index')); ?>">Roles</a></li>
                        <li class="breadcrumb-item active">Rol Permisos</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div>
    </div>
    <!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="card">
        
        <div class="card-body ">
            <div class="row">
                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                    <div class="container-fluid">
                        <form action="<?php echo e(route('roles_permisos',$rol->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <?php $__currentLoopData = user_permissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="card card-nav-tabs">
                                            <div class="card-header card-header-primary d-flex align-items-center">
                                                <?php echo $value['icon']; ?>

                                                <p class="mb-0" style="font-size: 30px">
                                                    <?php echo e($value['title']); ?>

                                                </p>
                                            </div>
                                            <div class="card-body">
                                                <?php $__currentLoopData = $value['keys']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-check">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="checkbox" name="<?php echo e($k); ?>" value="true" <?php if(kvfj($rol->permisos,$k)): ?> checked <?php endif; ?>>
                                                            <?php echo e($v); ?>

                                                            <span class="form-check-sign">
                                                                <span class="check"></span>
                                                            </span>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <input type="submit" value="Guardar" class="btn btn-primary">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hotel\laravel\resources\views/roles/permisos.blade.php ENDPATH**/ ?>