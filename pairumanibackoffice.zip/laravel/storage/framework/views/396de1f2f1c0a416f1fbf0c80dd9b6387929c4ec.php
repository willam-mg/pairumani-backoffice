<ul class="nav">
    
        
            <!-- SECCION USUARIOS -->
            <li class="nav-item <?php echo e(setActiveRoute(['usuarios_index','usuarios_create','usuarios_edit'])); ?>">
                <a href="<?php echo e(route('usuarios_index')); ?>" class="nav-link">
                    <i class="material-icons">people_alt</i>
                    <p>
                        Usuarios
                    </p>
                </a>
            </li>
        
            <!-- SECCION ROLES -->
            <li class="nav-item <?php echo e(setActiveRoute(['roles_index','roles_create','roles_edit','roles_permisos'])); ?>">
                <a href="<?php echo e(route('roles_index')); ?>" class="nav-link">
                    <i class="material-icons">privacy_tip</i>
                    <p>
                        Roles
                    </p>
                </a>
            </li>
        
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item <?php echo e(setActiveRoute(['acompanantes_index','acompanantes_create','acompanantes_edit','acompanantes_show'])); ?>">
                <a href="<?php echo e(route('acompanantes_index')); ?>" class="nav-link">
                    <i class="material-icons">people_alt</i>
                    <p>
                        Acompañantes
                    </p>
                </a>
            </li>
        
        
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item <?php echo e(setActiveRoute(['clientes_index','clientes_create','clientes_edit','clientes_show'])); ?>">
                <a href="<?php echo e(route('clientes_index')); ?>" class="nav-link">
                    <i class="material-icons">people_alt</i>
                    <p>
                        Clientes
                    </p>
                </a>
            </li>
                
        
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item <?php echo e(setActiveRoute(['eventos_index','eventos_create','eventos_edit','eventos_show','eventos_galeria'])); ?>">
                <a href="<?php echo e(route('eventos_index')); ?>" class="nav-link">
                    <i class="material-icons">event</i>
                    <p>
                        Eventos
                    </p>
                </a>
            </li>
                
        
            <!-- SECCION HABITACION CATEGORIAS -->
            <li class="nav-item <?php echo e(setActiveRoute(['habitacioncategorias_index','habitacioncategorias_create','habitacioncategorias_edit','habitacioncategorias_show'])); ?>">
                <a href="<?php echo e(route('habitacioncategorias_index')); ?>" class="nav-link">
                    <i class="material-icons">assignment</i>
                    <p>
                        Habitacion Categorias
                    </p>
                </a>
            </li>
                
        
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item <?php echo e(setActiveRoute(['habitaciones_index','habitaciones_create','habitaciones_edit','habitaciones_show','habitaciones_galeria'])); ?>">
                <a href="<?php echo e(route('habitaciones_index')); ?>" class="nav-link">
                    <i class="material-icons">meeting_room</i>
                    <p>
                        Habitaciones
                    </p>
                </a>
            </li>
                
        
            <!-- SECCION ACOMPAÑANTES -->
            <li class="nav-item <?php echo e(setActiveRoute(['promociones_index','promociones_create','promociones_edit','promociones_show'])); ?>">
                <a href="<?php echo e(route('promociones_index')); ?>" class="nav-link">
                    <i class="material-icons">campaign</i>
                    <p>
                        Promociones
                    </p>
                </a>
            </li>
                
    
</ul><?php /**PATH C:\laragon\www\pairumanibackoffice\laravel\resources\views/layouts/partials/nav.blade.php ENDPATH**/ ?>